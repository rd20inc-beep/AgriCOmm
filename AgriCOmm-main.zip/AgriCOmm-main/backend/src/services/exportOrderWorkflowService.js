// Backward compatibility — re-exports from modular location
module.exports = require('../modules/exportOrders/exportOrders.workflow');
