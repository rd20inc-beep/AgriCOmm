// Backward compatibility — re-exports from modular location
module.exports = require('../modules/analytics/smart.service');
